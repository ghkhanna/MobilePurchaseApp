package com.cg.payroll.services;

import java.sql.SQLException;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;

public class PayrollServicesImpl implements PayrollServices {
	
	private AssociateDAO associateDAO = new AssociateDAOImpl() ;
	private static final java.util.logging.Logger logger = Logger.getLogger(PayrollServicesImpl.class);
	
	@Override
	public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
			String designation, String pancard, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode) throws PayrollServicesDownException {
		Associate associate = new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new BankDetails(accountNumber, bankName, ifscCode), new Salary(basicSalary, epf, companyPf)); 
		
		try {
			associate=associateDAO.save(associate);
			return associate.getAssociateID();
			logger.info(""+);
			logger.
		} catch (SQLException e) {
			logger.error(e.getMessage()+ " " +e.getCause()+ " " +e.getErrorCode());
			e.printStackTrace();
		}
		
		return associate.getAssociateID();
	}
	@Override
	public int calculateNetSalary(int associateId)
			throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		Associate associate = getAssociateDetails(associateId);
		if(associate==null) throw new AssociateDetailsNotFoundException("Associate Details Not Found");
		else{
			associate.getSalary().setHra((30*associate.getSalary().getBasicSalary()/100));
		associate.getSalary().setOtherAllowance((20*associate.getSalary().getBasicSalary()/100));
		associate.getSalary().setPersonalAllowance((25*associate.getSalary().getBasicSalary()/100));
		associate.getSalary().setConveyenceAllowance((10*associate.getSalary().getBasicSalary()/100));
		associate.getSalary().setGrossSalary((associate.getSalary().getBasicSalary()+associate.getSalary().getHra()
				+associate.getSalary().getPersonalAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getEpf()+associate.getSalary().getCompanyPf()));
		int annualGrossSalary = associate.getSalary().getGrossSalary() * 12;
		int annualTax = 0; 
		if(annualGrossSalary > 250000 && annualGrossSalary <= 500000)
			annualTax = (int) (.05 * (annualGrossSalary-250000));
		if(annualGrossSalary > 500000 && annualGrossSalary <= 1000000)
			annualTax = (int) (.05 * 250000 + .2 * (annualGrossSalary - 500000));
		if(annualGrossSalary > 1000000)
			annualTax = (int) (.05 * 250000 + .2 * 500000 + .3 * (annualGrossSalary - 1000000));
		associate.getSalary().setMonthlyTax(annualTax / 12);
		associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary() - associate.getSalary().getMonthlyTax() - associate.getSalary().getCompanyPf() - associate.getSalary().getEpf());
		return associate.getSalary().getNetSalary();
		}
	}
	@Override
	public Associate getAssociateDetails(int associateId)
			throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		Associate associate = null;
		try {
			associate = associateDAO.findOne(associateId);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(associate==null) throw new AssociateDetailsNotFoundException("Associate Details Not Found");
		return associate;
	}
	@Override
	public ArrayList<Associate>getAllAssociatesDetails() throws PayrollServicesDownException {
		try {
			return associateDAO.findAll();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public String acceptAssociateDetails(String firstName, String lastName,
			String emailId, String department, String designation,
			String pancard, int yearlyInvestmentUnder8oC, double basicSalary,
			double epf, double companyPf, double accountNumber,
			String bankName, String ifscCode) {
		return null;
	}
}