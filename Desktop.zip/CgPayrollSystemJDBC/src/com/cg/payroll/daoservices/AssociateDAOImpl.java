package com.cg.payroll.daoservices;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.util.ConnectionProvider;
public class AssociateDAOImpl implements AssociateDAO {
	
	private Connection conn = 	ConnectionProvider.getDBConnection();
	
//	private static HashMap<Integer,Associate> associates = new HashMap<>();
	private static int ASSOCIATE_ID_COUNTER=10;
	
	/*private static  Associate []  associates = new Associate[10];
	private static int ASSOCIATE_IDX=0;*/
	
	@Override
	public Associate save(Associate associate) throws SQLException {
		try{
			conn.setAutoCommit(false);
			PreparedStatement pstmt1 = conn.prepareStatement("insert into Associate(associateId, yearlyInvestmentUnder8oC, firstName, lastName, department, designation, pancard, emailId) values (associateId.nextval, ?,?,?,?,?,?,?");
			pstmt1.setInt(1,associate.getYearlyInvestmentUnder80C());
			pstmt1.setString(2,associate.getFirstName());
			pstmt1.setString(3,associate.getLastName());
			pstmt1.setString(4,associate.getDepartment());
			pstmt1.setString(5,associate.getDesignation());
			pstmt1.setString(6,associate.getPancard());
			pstmt1.setString(7,associate.getEmailId());
			pstmt1.executeUpdate();
			
			PreparedStatement pstmt2 = conn.prepareStatement("select max(associateId) from Associate");
			
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			int associateId = rs.getInt(1);
			
			PreparedStatement pstmt3 = conn.prepareStatement("insert into BankDetails values(?,?,?,?");
			pstmt3.setInt(1, associateId);
			pstmt3.setInt(2, associate.getBankDetails().getAccountNumber());
			pstmt3.setString(3, associate.getBankDetails().getBankName());
			pstmt3.setString(4, associate.getBankDetails().getIfscCode());
			pstmt3.executeUpdate();
			
			PreparedStatement pstmt4 = conn.prepareStatement("insert into Salary(basicSalary, epf, companypf) values (?,?,?)");
			pstmt4.setInt(1,associateId);
			pstmt4.setInt(2, associate.getSalary().getBasicSalary());
			pstmt4.setInt(2, associate.getSalary().getEpf());
			pstmt4.setInt(2, associate.getSalary().getCompanyPf());
			pstmt4.executeUpdate();
			
			conn.commit();
			associate.setAssociateID(associateId);
			return associate;
		}
		catch(SQLException e){
			e.printStackTrace();
			conn.rollback();
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
//		associate.setAssociateID(ASSOCIATE_ID_COUNTER++);
//		associates.put(associate.getAssociateID(), associate);
//		return associate;
	}
	@Override
	public Associate findOne(int associateId) throws SQLException {
		PreparedStatement pstmt1 = conn.prepareStatement("Select * from Associate where associateId =" + associateId);
		ResultSet associateRS = pstmt1.executeQuery();
		if(associateRS.next()){
			String firstName = associateRS.getString("firstName");
			String lastName = associateRS.getString("lastName");
			String department = associateRS.getString("department");
			String designation = associateRS.getString("designation");
			String pancard = associateRS.getString("pancard");
			String emailId = associateRS.getString("emailId");
			int yearlyInvestmentUnder80C = associateRS.getInt("yearlyInvestmentUnder80C");
			Associate associate = new Associate(associateId, yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, null, null);
			
			PreparedStatement pstmt2 = conn.prepareStatement("select * from BankDetails where associateId=" + associateId);
			ResultSet bankDetailsRS = pstmt2.executeQuery();
			bankDetailsRS.next();
			
			int accountNumber=bankDetailsRS.getInt("accountNumber");
			String BankName = bankDetailsRS.getString("BankName");
			String IfscCode = bankDetailsRS.getString("IfscCode");
			associate.setBankDetails(new BankDetails(accountNumber, BankName, IfscCode));
			
			PreparedStatement pstmt3 = conn.prepareStatement("select * from Salary where associateId=" +associateId);
			
			ResultSet salaryRS = pstmt3.executeQuery();
			salaryRS.next();
			associate.setSalary(new Salary(salaryRS.getInt("basicSalary"), salaryRS.getInt("hra"), salaryRS.getInt("conveyenceAllowance"), salaryRS.getInt("otherAllowance"), salaryRS.getInt("personalAllowance"), salaryRS.getInt("monthlyTax"), salaryRS.getInt("epf"), salaryRS.getInt("companyPf"), salaryRS.getInt("gratuity"), salaryRS.getInt("grossSalary"), salaryRS.getInt("netSalary")));
			return associate;
		}
		return null;
		}
		
		//return associates.get(associateId);
		/*for(int i=0;i<associates.length;i++) 
			if(associates[i]!=null&& associateId==associates[i].getAssociateID())
				return associates[i];
		return null;*/
	
	@Override
	public ArrayList <Associate> findAll() throws SQLException{
		PreparedStatement pstmt1 = conn.prepareStatement("Select * from Associate1");
		ResultSet associateRS = pstmt1.executeQuery();
		
		ArrayList<Associate>associate = new ArrayList<>();
		while(associateRS.next()){
			String firstName = associateRS.getString("firstName");
			String lastName = associateRS.getString("lastName");
			String department = associateRS.getString("department");
			String designation = associateRS.getString("designation");
			String pancard = associateRS.getString("pancard");
			String emailId = associateRS.getString("emailId");
			int yearlyInvestmentUnder80C = associateRS.getInt("yearlyInvestmentUnder80C");
			Associate Associate = new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, null, null);
			
			PreparedStatement pstmt2 = conn.prepareStatement("select * from BankDetails");
			ResultSet bankDetailsRS = pstmt2.executeQuery();
			bankDetailsRS.next();
			
			int accountNumber=bankDetailsRS.getInt("accountNumber");
			String BankName = bankDetailsRS.getString("BankName");
			String IfscCode = bankDetailsRS.getString("IfscCode");
			Associate.setBankDetails(new BankDetails(accountNumber, BankName, IfscCode));
			
			PreparedStatement pstmt3 = conn.prepareStatement("select * from Salary");
			
			ResultSet salaryRS = pstmt3.executeQuery();
			salaryRS.next();
			Associate.setSalary(new Salary(salaryRS.getInt("basicSalary"), salaryRS.getInt("hra"), salaryRS.getInt("conveyenceAllowance"), salaryRS.getInt("otherAllowance"), salaryRS.getInt("personalAllowance"), salaryRS.getInt("monthlyTax"), salaryRS.getInt("epf"), salaryRS.getInt("companyPf"), salaryRS.getInt("gratuity"), salaryRS.getInt("grossSalary"), salaryRS.getInt("netSalary")));
			return new ArrayList<>(associates.values());
			}
		return associate;
	}
		@Override
		public boolean update(Associate Associate) throws SQLException{
			try{
				conn.setAutoCommit(false);
				PreparedStatement pstmt1 = conn.prepareStatement("update table Salary");
				pstmt1.setInt(1, Associate.getSalary().setBasicSalary(10000));
				pstmt1.setInt(1, Associate.getSalary().setCompanyPf(100));
				pstmt1.setInt(1, Associate.getSalary().getConveyenceAllowance(200));
				pstmt1.setInt(1, Associate.getSalary().getGratuity(150));
				pstmt1.executeUpdate();
			}
			catch(SQLException e){
				e.printStackTrace();
				conn.rollback();
				throw e;
			}
			finally{
				conn.setAutoCommit(true);
			}
			return false;
			
			
		}
}
