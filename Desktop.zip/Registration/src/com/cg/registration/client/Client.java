package com.cg.registration.client;
import com.cg.registration.beans.Customer;
import com.cg.registration.services.RegistrationServices;
import com.cg.registration.services.RegistrationServicesImpl;
public class Client {
	public static void main(String[]args){
		RegistrationServices registrationServices = new RegistrationServicesImpl();
		Customer customer = registrationServices.addCustomer(677218, 35, 215, 567, "Chehak");
		System.out.println(registrationServices.printCustomerDetails(customer));
		System.out.println(registrationServices.getCustomerDetails(1));
		
	}
}
