package com.cg.registration.daoservices;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.registration.util.ConnectionProvider;
import com.cg.registration.beans.Customer;
public class RegistrationDAOImpl implements RegistrationDAO{
	private Connection conn = ConnectionProvider.getDBConnection();
	@Override
	public Customer saveCustomer(Customer customer) throws SQLException {
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1 = conn.prepareStatement("insert into Registration(registrationId, mobileNo, age, registrationFees, actualRegFeesPaid, comission, customerName) values(registrationId_Seq.nextVal, ?, ?, ?, ?, ?, ?)");
			pstmt1.setInt(1, customer.getMobileNo());
			pstmt1.setInt(2, customer.getAge());
			pstmt1.setInt(3, customer.getRegistrationFees());
			pstmt1.setInt(4, customer.getActualRegFeesPaid());
			pstmt1.setInt(5, customer.getComission());
			pstmt1.setString(6, customer.getCustomerName());
			pstmt1.executeUpdate();
			conn.commit();
			
			PreparedStatement pstmt2 = conn.prepareStatement("select max(registrationId) from Registration");
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			int registrationId = rs.getInt(1);
			customer.setRegistrationId(registrationId);
			return customer;
		}catch (SQLException e) {
			conn.rollback();
			e.printStackTrace();
			return null;
		}finally{
			conn.setAutoCommit(true);
		}
	}
	@Override
	public Customer findOne(int registrationId) throws SQLException {
		try {
			PreparedStatement pstmt1 = conn.prepareStatement("select * from Registration where registrationId=" +registrationId);
			ResultSet registrationIdRS = pstmt1.executeQuery();
			if(registrationIdRS.next()) {
				int mobileNo = registrationIdRS.getInt("mobileNo");
				int age = registrationIdRS.getInt("age");
				int registrationFees = registrationIdRS.getInt("registrationFees");
				int actualRegFeesPaid = registrationIdRS.getInt("actualRegFeesPaid");
				int comission = registrationIdRS.getInt("comission");
				String customerName = registrationIdRS.getString("customerName");
				
				Customer customer = new Customer(registrationId, mobileNo, age, registrationFees, actualRegFeesPaid, comission, customerName);
				return customer;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			conn.setAutoCommit(true);
		}
		return null;
	}

	@Override
	public Customer findOne(String customerName) {
		return null;
	}

}
