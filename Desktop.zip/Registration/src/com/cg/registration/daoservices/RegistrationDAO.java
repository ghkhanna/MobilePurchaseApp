package com.cg.registration.daoservices;

import java.sql.SQLException;

import com.cg.registration.beans.Customer;

public interface RegistrationDAO {
	Customer saveCustomer(Customer customer) throws SQLException;
	Customer findOne(int registrationId) throws SQLException;
	Customer findOne(String customerName);
}
