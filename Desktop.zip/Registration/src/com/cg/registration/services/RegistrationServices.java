package com.cg.registration.services;

import com.cg.registration.beans.Customer;

public interface RegistrationServices {
	Customer addCustomer( int mobileNo, int age, int registrationFees, int actualRegFeesPaid, String customerName);
	Customer printCustomerDetails(Customer customer);
	Customer getCustomerDetails(int registrationId);
}
