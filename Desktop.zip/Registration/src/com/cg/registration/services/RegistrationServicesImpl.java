package com.cg.registration.services;
import java.sql.SQLException;

import com.cg.registration.beans.Customer;
import com.cg.registration.daoservices.RegistrationDAO;
import com.cg.registration.daoservices.RegistrationDAOImpl;
public class RegistrationServicesImpl implements RegistrationServices{
	private RegistrationDAO registrationDAO = new RegistrationDAOImpl();

	@Override
	public Customer addCustomer(int mobileNo, int age, int registrationFees,
			int actualRegFeesPaid, String customerName) {
		int comission=0;
		try {
			if(age>0 && age<=18)
				comission=0;
			else if(age>18 && age<=25)
				comission=10;
			else if(age>25 && age<=50)
				comission=20;
			else if(age>50)
				comission=30;
			Customer customer = new Customer(mobileNo, age, registrationFees, actualRegFeesPaid, comission, customerName);
			customer = registrationDAO.saveCustomer(customer);
			return customer;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	@Override
	public Customer printCustomerDetails(Customer customer){
		try {
			registrationDAO.findOne(customer.getRegistrationId());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return customer;
	}
	@Override
	public Customer getCustomerDetails(int registrationId) {
		 Customer customer;
		try {
			customer = registrationDAO.findOne(registrationId);
			return customer;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

}
