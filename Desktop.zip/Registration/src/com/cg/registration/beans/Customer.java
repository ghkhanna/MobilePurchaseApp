package com.cg.registration.beans;

public class Customer {
	int registrationId, mobileNo, age, registrationFees, actualRegFeesPaid, comission;
	String customerName;
	public Customer() {
		super();
	}
	public Customer(int registrationId, int mobileNo, int age,
			int registrationFees, int actualRegFeesPaid, int comission,
			String customerName) {
		super();
		this.registrationId = registrationId;
		this.mobileNo = mobileNo;
		this.age = age;
		this.registrationFees = registrationFees;
		this.actualRegFeesPaid = actualRegFeesPaid;
		this.comission = comission;
		this.customerName = customerName;
	}
	public Customer(int mobileNo, int age,
			int registrationFees, int actualRegFeesPaid, int comission,
			String customerName) {
		super();
		this.mobileNo = mobileNo;
		this.age = age;
		this.registrationFees = registrationFees;
		this.actualRegFeesPaid = actualRegFeesPaid;
		this.comission = comission;
		this.customerName = customerName;
	}
	@Override
	public String toString() {
		return "Customer [registrationId=" + registrationId + ", mobileNo="
				+ mobileNo + ", age=" + age + ", registrationFees="
				+ registrationFees + ", actualRegFeesPaid=" + actualRegFeesPaid
				+ ", comission=" + comission + ", customerName=" + customerName
				+ "]";
	}
	public int getRegistrationId() {
		return registrationId;
	}
	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getRegistrationFees() {
		return registrationFees;
	}
	public void setRegistrationFees(int registrationFees) {
		this.registrationFees = registrationFees;
	}
	public int getActualRegFeesPaid() {
		return actualRegFeesPaid;
	}
	public void setActualRegFeesPaid(int actualRegFeesPaid) {
		this.actualRegFeesPaid = actualRegFeesPaid;
	}
	public int getComission() {
		return comission;
	}
	public void setComission(int comission) {
		this.comission = comission;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + actualRegFeesPaid;
		result = prime * result + age;
		result = prime * result + comission;
		result = prime * result
				+ ((customerName == null) ? 0 : customerName.hashCode());
		result = prime * result + mobileNo;
		result = prime * result + registrationFees;
		result = prime * result + registrationId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (actualRegFeesPaid != other.actualRegFeesPaid)
			return false;
		if (age != other.age)
			return false;
		if (comission != other.comission)
			return false;
		if (customerName == null) {
			if (other.customerName != null)
				return false;
		} else if (!customerName.equals(other.customerName))
			return false;
		if (mobileNo != other.mobileNo)
			return false;
		if (registrationFees != other.registrationFees)
			return false;
		if (registrationId != other.registrationId)
			return false;
		return true;
	}
}