package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.util.ConnectionProvider;
 
public class DemandDraftDAO implements IDemandDraftDAO{
 
	private Connection conn = 	ConnectionProvider.getDBConnection();
 
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException {
		try{
			conn.setAutoCommit(false);
			PreparedStatement pstmt1 = conn.prepareStatement("insert into demand_draft(transaction_id , dd_amount, customer_name , in_favor_of , dd_description, phone_number, dd_commission, date_of_transaction)values(Transaction_Id_Seq.nextval,?,?,?,?,?,?,?)");
			pstmt1.setInt(1, demandDraft.getDdAmount());
			pstmt1.setString(2, demandDraft.getCustomerName());
			pstmt1.setString(3, demandDraft.getInFavorOf());
			pstmt1.setString(4, demandDraft.getDdDescription());
			pstmt1.setInt(5, demandDraft.getPhoneNumber());
			pstmt1.setInt(6, demandDraft.getDdCommission());
			pstmt1.setDate(7, (java.sql.Date) demandDraft.getDateOfTransaction());
			pstmt1.executeUpdate();
			PreparedStatement pstmt2 = conn.prepareStatement("select max(transaction_id) from demand_draft");
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			int transaction_id = rs.getInt(1);
 
			conn.commit();
			demandDraft.setTransactionId(transaction_id);
			return demandDraft.getTransactionId();
		}catch(SQLException e){
			e.printStackTrace();
			conn.rollback();
			throw e;
		}finally{
			conn.setAutoCommit(true);
		}
	}			
 
		@Override
		public DemandDraft getDemandDraftDetails(int transactionId) throws SQLException {
			PreparedStatement pstmt1 = conn.prepareStatement("Select * from demand_draft where transaction_id ="+transactionId);
			ResultSet demandDraftRS = pstmt1.executeQuery();
			if(demandDraftRS.next()){
				String customer_name = demandDraftRS.getString("customer_name");
				String in_favor_of = demandDraftRS.getString("in_favor_of");
				String phone_number = demandDraftRS.getString("phone_number");
				Date date_of_transaction = demandDraftRS.getDate("date_of_transaction");
				int dd_amount = demandDraftRS.getInt("dd_amount");
				int dd_commission = demandDraftRS.getInt("dd_commission");
				String dd_description = demandDraftRS.getString("dd_description");
				DemandDraft demandDraft = new DemandDraft(customer_name, in_favor_of, phone_number, date_of_transaction, dd_amount, dd_commission, dd_description);
				//DemandDraft demandDraft = new DemandDraft(transactionId, ddAmount, ddCommission, customerName, inFavorOf, dddescription, phoneNumber, dateofTransaction);
				return demandDraft;
		}
			return null;
 
	}

		@Override
		public DemandDraft save(DemandDraft demandDraft) {
			return null;
		}
}