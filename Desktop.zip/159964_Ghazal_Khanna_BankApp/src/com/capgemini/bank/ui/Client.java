package com.capgemini.bank.ui;

import java.util.Date;
import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exception.DemandDraftDetailsNotFoundException;
import com.capgemini.bank.exception.DemandDraftServiceException;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;

public class Client {
	public static void main(String[]args){
		IDemandDraftService demandDraftService = new DemandDraftService();
		IDemandDraftDAO demandDraftDAO = new DemandDraftDAO();
		
		
		try {
			System.out.println(demandDraftService.getDemandDraftDetails(123456));
		} catch (DemandDraftServiceException
				| DemandDraftDetailsNotFoundException e) {
			e.printStackTrace();
		}
		
		System.out.println("Enter the name of the customer");
		Scanner s = new Scanner(System.in);
		String customerName = s.nextLine();
		System.out.println("Enter customer phone number");
		int phoneNumber = s.nextInt();
		System.out.println("In favor of");
		String inFavorOf = s.nextLine();
		System.out.println("Enter Demand Draft amount(in Rs)");
		int ddAmount = s.nextInt();
		System.out.println("Enter Remarks)");
		String ddDescription = s.nextLine();
		
		System.out.println("Your Demand Draft request has been successfully registered along with 10001");
	//	DemandDraft demandDraft1 = new DemandDraft(123456, 78635678, 2000, 500, "Ghazal", "Fees", "School fees", dateOfTransaction);
	//	System.out.println(demandDraft1.getTransactionId());
		//System.out.println(demandDraftService.addDemandDraftDetails
	}
}