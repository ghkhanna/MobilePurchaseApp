package com.capgemini.bank.bean;

import java.util.Date;

public class DemandDraft {
	int transactionId, phoneNumber, ddAmount, ddCommission;
	String customerName, inFavorOf, ddDescription;
	Date dateOfTransaction;
	private String customer_name;
	private String in_favor_of;
	private String phone_number;
	private java.sql.Date date_of_transaction;
	private int dd_amount;
	private int dd_commission;
	private String dd_description;
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public int getDdAmount() {
		return ddAmount;
	}
	public void setDdAmount(int ddAmount) {
		this.ddAmount = ddAmount;
	}
	public int getDdCommission() {
		return ddCommission;
	}
	public void setDdCommission(int ddCommission) {
		this.ddCommission = ddCommission;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getInFavorOf() {
		return inFavorOf;
	}
	public void setInFavorOf(String inFavorOf) {
		this.inFavorOf = inFavorOf;
	}
	public String getDdDescription() {
		return ddDescription;
	}
	public void setDdDescription(String ddDescription) {
		this.ddDescription = ddDescription;
	}
	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}
	public void setDateOfTransaction(Date dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}
	public DemandDraft() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DemandDraft(int transactionId, int phoneNumber, int ddAmount,
			int ddCommission, String customerName, String inFavorOf,
			String ddDescription, Date dateOfTransaction) {
		super();
		this.transactionId = transactionId;
		this.phoneNumber = phoneNumber;
		this.ddAmount = ddAmount;
		this.ddCommission = ddCommission;
		this.customerName = customerName;
		this.inFavorOf = inFavorOf;
		this.ddDescription = ddDescription;
		this.dateOfTransaction = dateOfTransaction;
	}
	public DemandDraft(String customer_name, String in_favor_of,
			String phone_number, java.sql.Date date_of_transaction,
			int dd_amount, int dd_commission, String dd_description) {
		super();
		this.customer_name = customer_name;
		this.in_favor_of = in_favor_of;
		this.phone_number = phone_number;
		this.date_of_transaction = date_of_transaction;
		this.dd_amount = dd_amount;
		this.dd_commission = dd_commission;
		this.dd_description = dd_description;
	}
	
}
