package com.capgemini.bank.service;
import java.sql.SQLException;
import java.util.Date;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exception.DemandDraftDetailsNotFoundException;
import com.capgemini.bank.exception.DemandDraftServiceException;
import com.sun.istack.internal.logging.Logger;


	public class DemandDraftService implements IDemandDraftService {
	
	private IDemandDraftDAO demandDraftDAO = new DemandDraftDAO();
	private static final Logger logger = Logger.getLogger(DemandDraftService.class);


	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft)
			throws DemandDraftServiceException {
		if(demandDraft.getDdAmount()<=5000)
			demandDraft.setDdCommission(10);
		else if(demandDraft.getDdAmount()>5000 && demandDraft.getDdAmount()<=10000)
			demandDraft.setDdCommission(41);
		else if(demandDraft.getDdAmount()>10000 && demandDraft.getDdAmount()<=100000)
			demandDraft.setDdCommission(51);
		else if(demandDraft.getDdAmount()>100000 && demandDraft.getDdAmount()<=500000)
			demandDraft.setDdCommission(306);
		int Id;
		try {
			Id = demandDraftDAO.addDemandDraftDetails(demandDraft);
		} catch (SQLException e) {
			logger.error(e.getMessage()+" "+e.getCause()+" "+e.getErrorCode());
			e.printStackTrace();
			throw new DemandDraftServiceException("Server is down", e);
		}
		return 0;
	}
	@Override
	public DemandDraft getDemandDraftDetails(int transactionId)
			throws DemandDraftServiceException,
			DemandDraftDetailsNotFoundException {
		return null;
	}

	
	

}
