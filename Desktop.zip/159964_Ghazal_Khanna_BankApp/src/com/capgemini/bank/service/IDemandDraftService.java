package com.capgemini.bank.service;

import java.util.Date;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.DemandDraftDetailsNotFoundException;
import com.capgemini.bank.exception.DemandDraftServiceException;

public interface IDemandDraftService {
	DemandDraft getDemandDraftDetails(int transactionId) throws DemandDraftServiceException, DemandDraftDetailsNotFoundException;
	int addDemandDraftDetails(DemandDraft demandDraft) throws DemandDraftServiceException;
}