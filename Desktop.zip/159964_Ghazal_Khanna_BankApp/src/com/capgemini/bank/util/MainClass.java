package com.capgemini.bank.util;

public class MainClass {

	public static void main(String[] args) {
		if(ConnectionProvider.getDBConnection()!=null)
			System.out.println("Connection open");
		else
			System.out.println("not made");

	}

}
