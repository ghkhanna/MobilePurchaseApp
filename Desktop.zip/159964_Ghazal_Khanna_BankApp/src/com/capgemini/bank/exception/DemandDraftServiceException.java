package com.capgemini.bank.exception;

public class DemandDraftServiceException extends Exception {}
