package com.capgemini.bank.service;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.capgemini.bank.bean.DemandDraft;

import org.apache.log4j.Logger;

import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exception.DemandDraftServicesDownException;
public class DemandDraftService implements IDemandDraftService {
	private IDemandDraftDAO demandDraftDAO = new DemandDraftDAO();
	private static final Logger logger = Logger.getLogger(DemandDraftService.class);
	@Override
	public int addDemandDraftDetails(String customerName, String phoneNumber,
			String inFavorOf, int ddAmount, String ddDescription) throws DemandDraftServicesDownException {
		try{
			int ddCommission=0;
			if(ddAmount<=5000)
				ddCommission=10;
			else if(ddAmount>5000 && ddAmount<=10000)
				ddCommission=41;
			else if(ddAmount>10000 && ddAmount<=100000)
				ddCommission=51;
			else if(ddAmount>100000 && ddCommission<=500000)
				ddCommission=306;
			DemandDraft demandDraft = new DemandDraft(customerName, inFavorOf, phoneNumber, ddAmount, ddCommission, ddDescription);
			return demandDraftDAO.addDemandDraftDetails(demandDraft);
		} catch (SQLException e) {
			/*e.printStackTrace();*/
			logger.error(e.getMessage()+" "+e.getCause()+" "+e.getErrorCode());
			throw new DemandDraftServicesDownException("Demand draft services down. Please try again.");
		}
	}
	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws DemandDraftServicesDownException {
		DemandDraft demandDraft;
		try {
			demandDraft = demandDraftDAO.getDemandDraftDetails(transactionId);
			return demandDraft;
		}  catch (SQLException e) {
			logger.error(e.getMessage()+" "+e.getCause()+" "+e.getErrorCode());
			throw new DemandDraftServicesDownException("Demand draft services down. Please try again.");
		}
	}
}