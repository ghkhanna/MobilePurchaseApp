package com.capgemini.bank.ui;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.bank.exception.DemandDraftServicesDownException;
import com.capgemini.bank.exception.InvalidInputException;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;
import com.capgemini.bank.util.ConnectionProvider;
public class Client {
	public static void main(String[] args) throws DemandDraftServicesDownException, InvalidInputException {
		if (ConnectionProvider.getDBConnection() != null)
			System.out.println("Successfully Connected");
		else
			System.out.println("Not Connected");
		IDemandDraftService demandDraftService = new DemandDraftService();
		int choice=0;
		Scanner s  = new Scanner(System.in);
		System.out.println("1. Enter Demand Draft Details");
		System.out.println("2. Exit");
		try{
			choice = s.nextInt();
			while(choice==1){
				System.out.println("Enter the name of the customer : ");
				s.nextLine();
				String customerName = s.nextLine();
				System.out.println("Enter customer phone number: ");
				String phoneNumber = s.nextLine();
				if(phoneNumber.length()!=10)
					throw new InvalidInputException("Please enter valid input.");
				System.out.println("In favor of: ");
				String inFavorOf = s.nextLine();
				System.out.println("Enter Demand Draft amount(in Rs.): ");
				int ddAmount = s.nextInt();
				if(ddAmount<=0)
					throw new InvalidInputException("Please enter valid input.");
				System.out.println("Enter Remarks: ");
				s.nextLine();
				String ddDescription = s.nextLine();
				int transactionId = demandDraftService.addDemandDraftDetails(customerName,phoneNumber,inFavorOf,ddAmount,ddDescription);
				System.out.println("Your Demand Draft request has been successfully registered along with the  "+transactionId);
			}
		}catch(InputMismatchException e){
			System.out.println("Please enter valid input.");
		}
	}
}
