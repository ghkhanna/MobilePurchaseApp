package com.cg.project.client;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.project.beans.Mobile;
import com.cg.project.beans.PurchaseDetails;
import com.cg.project.exceptions.MobileNotAvailableException;
import com.cg.project.services.MobileServices;
import com.cg.project.services.MobileServicesImpl;
public class Client {
	public static void main(String[] args) throws MobileNotAvailableException, SQLException {
		MobileServices mobileServices = new MobileServicesImpl();
		Mobile mobile = new Mobile();
		PurchaseDetails purchaseDetails = new PurchaseDetails();
		int choice=0;
		mobileServices.deleteMobileDetails(1001);
		Scanner SC = new Scanner(System.in);
		System.out.println("1.Enter Mobile Details");
		System.out.println("2.Enter Purchase Details");
		
		choice = SC.nextInt();
		while(choice==1){
			System.out.println("Enter Mobile name");
			String name = SC.next();
			System.out.println("Enter Mobile number");
			int mobileNo = SC.nextInt();
			System.out.println("Enter price");
			int price = SC.nextInt();
			System.out.println("Enter quantity");
			int quantity = SC.nextInt();
		}
			while(choice==2){
				System.out.println("Enter phone number");
				int phoneNo = SC.nextInt();
				System.out.println("Enter mobile ID");
				int mobileId = SC.nextInt();
				System.out.println("Enter c name");
				String cName = SC.next();
				System.out.println("Enter mail ID");
				String mailId = SC.next();
				System.out.println("Enter purchase date");
				String purchaseDate = SC.next();
				PurchaseDetails purchaseDetails1 = new PurchaseDetails(phoneNo, mobileId, cName, mailId, purchaseDate);
				mobileServices.addPurchaseDetails(purchaseDetails1);
				System.out.println("Purchase Details successfully added with mobileId="+mobileId );
		}
	}
}
