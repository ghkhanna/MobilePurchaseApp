package com.cg.project.exceptions;

public class MobileNotAvailableException extends Exception {

	public MobileNotAvailableException(String string) {
	}
	
}
