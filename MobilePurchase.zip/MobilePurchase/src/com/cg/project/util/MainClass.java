package com.cg.project.util;

import com.cg.project.util.ConnectionProvider;

public class MainClass {

	public static void main(String[] args) {
		if(ConnectionProvider.getDBConnection()!=null)
			System.out.println("Connection open");
		else
			System.out.println("not made");

	}

}
