package com.cg.project.services;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.project.beans.Mobile;
import com.cg.project.beans.PurchaseDetails;
import com.cg.project.daoservices.CustomerDAO;
import com.cg.project.daoservices.CustomerDAOImpl;
import com.cg.project.exceptions.MobileNotAvailableException;

public class MobileServicesImpl implements MobileServices{
	CustomerDAO dao = new CustomerDAOImpl();
	private static Logger logger = Logger.getLogger(MobileServicesImpl.class);

	@Override
	public PurchaseDetails addPurchaseDetails(PurchaseDetails purchaseDetails) throws MobileNotAvailableException{
		Mobile mobile = new Mobile();
				if(mobile.getQuantity() != 0){
					mobile.setQuantity(mobile.getQuantity()-1);
					return purchaseDetails;
				}
				else
					throw new MobileNotAvailableException("Requested mobile not available");
	}

	@Override
	public boolean updateMobileDetails(Mobile mobile) throws SQLException {
		return dao.updateMobileDetails(mobile);
	}

	@Override
	public ArrayList<Mobile> find(int price) throws SQLException {
		logger.info("Array"+price);
		return dao.find(price);
	}

	@Override
	public ArrayList<Mobile> findAll() throws SQLException {
		return dao.findAll();
	}

	@Override
	public boolean deleteMobileDetails(int mobileId) throws SQLException {
		return dao.deleteMobileDetails(mobileId);
	}

	@Override
	public int addMobileDetails(String name, int mobileNo, int price,
			int quantity) {
		Mobile mobile = new Mobile(name, mobileNo, price, quantity);
		return 0;
	}
}
