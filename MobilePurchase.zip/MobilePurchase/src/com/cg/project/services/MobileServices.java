package com.cg.project.services;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.project.beans.Mobile;
import com.cg.project.beans.PurchaseDetails;
import com.cg.project.exceptions.MobileNotAvailableException;

public interface MobileServices {
	int addMobileDetails(String name, int mobileNo, int price, int quantity);
	public boolean deleteMobileDetails(int mobileId) throws SQLException;
	PurchaseDetails addPurchaseDetails(PurchaseDetails purchaseDetails)  throws MobileNotAvailableException;
	public boolean updateMobileDetails(Mobile mobile) throws SQLException;
	public ArrayList<Mobile> find(int price) throws SQLException;
	public ArrayList<Mobile>findAll() throws SQLException;
}