package com.cg.project.beans;

public class Mobile {
	String name;
	int mobileNo, mobileId, price, quantity;
	public Mobile() {
		super();
	}
	public Mobile(String name, int mobileNo, int mobileId, int price,
			int quantity) {
		super();
		this.name = name;
		this.mobileNo = mobileNo;
		this.mobileId = mobileId;
		this.price = price;
		this.quantity = quantity;
	}
	public Mobile(String name, int mobileNo, int price, int quantity) {
		this.name = name;
		this.mobileNo = mobileNo;
		this.price = price;
		this.quantity = quantity;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", mobileNo=" + mobileNo
				+ ", mobileId=" + mobileId + ", price=" + price + ", quantity="
				+ quantity + "]";
	}
}
