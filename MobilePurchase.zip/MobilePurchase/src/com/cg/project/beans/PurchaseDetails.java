package com.cg.project.beans;

import java.util.Date;

public class PurchaseDetails {
	int purchaseId, phoneNo, mobileId;
	String cName, mailId;
	String purchaseDate;
	public PurchaseDetails() {
		super();
	}
	public PurchaseDetails(int purchaseId, int phoneNo, int mobileId,
			String cName, String mailId, String purchaseDate) {
		super();
		this.purchaseId = purchaseId;
		this.phoneNo = phoneNo;
		this.mobileId = mobileId;
		this.cName = cName;
		this.mailId = mailId;
		this.purchaseDate = purchaseDate;
	}
	public PurchaseDetails(int phoneNo, int mobileId, String cName,
			String mailId, String purchaseDate) {
		super();
		this.phoneNo = phoneNo;
		this.mobileId = mobileId;
		this.cName = cName;
		this.mailId = mailId;
		this.purchaseDate = purchaseDate;
	}
	public int getPurchaseId() {
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId) {
		this.purchaseId = purchaseId;
	}
	public int getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(int phoneNo) {
		this.phoneNo = phoneNo;
	}
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	public String getcName() {
		return cName;
	}
	public void setcName(String cName) {
		this.cName = cName;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public String getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(String purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	@Override
	public String toString() {
		return "PurchaseDetails [purchaseId=" + purchaseId + ", phoneNo="
				+ phoneNo + ", mobileId=" + mobileId + ", cName=" + cName
				+ ", mailId=" + mailId + ", purchaseDate=" + purchaseDate + "]";
	}
}
