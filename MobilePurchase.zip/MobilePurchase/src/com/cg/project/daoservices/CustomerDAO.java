package com.cg.project.daoservices;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.project.beans.Mobile;
import com.cg.project.beans.PurchaseDetails;

public interface CustomerDAO {

	ArrayList<Mobile> findAll() throws SQLException;
	PurchaseDetails addPurchaseDetails(PurchaseDetails purchaseDetails) throws SQLException;
	boolean updateMobileDetails(Mobile mobile) throws SQLException;
	ArrayList<Mobile> find(int price) throws SQLException;
	boolean deleteMobileDetails(int mobileId) throws SQLException;
	Mobile addMobileDetails(Mobile mobile);
}