package com.cg.project.daoservices;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.project.util.ConnectionProvider;
import com.cg.project.beans.Mobile;
import com.cg.project.beans.PurchaseDetails;
public class CustomerDAOImpl implements CustomerDAO{
	private Connection conn = 	ConnectionProvider.getDBConnection();
	private static int MOBILE_ID_COUNTER = 101;
	@Override
	public ArrayList<Mobile> find(int price) throws SQLException {
		try {
			conn.setAutoCommit(false);
			PreparedStatement pstmt1=conn.prepareStatement("select * from Mobiles where price <=" +price);
			ResultSet mobileRS = pstmt1.executeQuery();
			
			ArrayList<Mobile> mobiles = new ArrayList<>();
			while(mobileRS.next()){
				int mobileNo = mobileRS.getInt("mobileNo");
				String name = mobileRS.getString("name");
				int quantity = mobileRS.getInt("quantity");
				
				Mobile mobile1 = new Mobile(name, mobileNo, price, quantity);
				mobiles.add(mobile1);
			}
			return mobiles;
		}catch (SQLException e) {
			conn.rollback();
			e.printStackTrace();
		}finally{
			conn.setAutoCommit(true);
		}
		return null;
	}
	@Override
	public PurchaseDetails addPurchaseDetails(PurchaseDetails purchaseDetails) throws SQLException {
		PreparedStatement pstmt1 = conn.prepareStatement("insert into PurchaseDetails(purchaseId, cName, mailId, phoneNo, purchaseDate, mobileId) values(purchaseId_Seq.nextVal, ?, ?, ?, ?,?)");
		pstmt1.setString(1, purchaseDetails.getcName());
		pstmt1.setString(2, purchaseDetails.getMailId());
		pstmt1.setInt(3, purchaseDetails.getPhoneNo());
		pstmt1.setString(4, purchaseDetails.getPurchaseDate());
		pstmt1.setInt(5, purchaseDetails.getMobileId());
		pstmt1.executeQuery();
		conn.commit();
		
		ResultSet rs = pstmt1.executeQuery();
		rs.next();
		int purchaseId = rs.getInt(1);
		return purchaseDetails;
	}
	public boolean updateMobileDetails(Mobile mobile) throws SQLException{
		PreparedStatement pstmt1;
		try {
			conn.setAutoCommit(false);
			pstmt1 = conn.prepareStatement("update table Mobile");
			pstmt1.setString(1,mobile.getName());
			pstmt1.setInt(2, mobile.getMobileNo());
			pstmt1.setInt(3, mobile.getMobileId());
			pstmt1.setInt(4, mobile.getPrice());
			pstmt1.setInt(5, mobile.getQuantity());
			pstmt1.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
			conn.rollback();
		} finally{
			conn.setAutoCommit(true);
		}
		return false;
	}
	@Override
	public ArrayList<Mobile> findAll() throws SQLException {
		conn.setAutoCommit(false);
		PreparedStatement pstmt1 = conn.prepareStatement("Select * from Mobile");
		ResultSet mobileRS = pstmt1.executeQuery();
		
		ArrayList<Mobile>mobiles = new ArrayList<>();
		while(mobileRS.next()){
			String name = mobileRS.getString("name");
			int mobileNo = mobileRS.getInt("mobileNo");
			int mobileId = mobileRS.getInt("mobileId");
			int price = mobileRS.getInt("price");
			int quantity = mobileRS.getInt("quantity");
			
			Mobile mobile1 = new Mobile(name, mobileNo, price, quantity);
			mobiles.add(mobile1);
			conn.commit();
		}
		return mobiles;
	}
	@Override
	public boolean deleteMobileDetails(int mobileId) throws SQLException {
		PreparedStatement pstmt1 = conn.prepareStatement("delete from Mobile where mobileId ="+mobileId);
		pstmt1.executeUpdate();
		conn.commit();
		return false;
	}
	@Override
	public Mobile addMobileDetails(Mobile mobile) {
		PreparedStatement pstmt1 = conn.prepareStatement("insert into mobile(purchaseId, cName, mailId, phoneNo, purchaseDate, mobileId) values(purchaseId_Seq.nextVal, ?, ?, ?, ?,?)");
		pstmt1.setString(1, purchaseDetails.getcName());
		pstmt1.setString(2, purchaseDetails.getMailId());
		pstmt1.setInt(3, purchaseDetails.getPhoneNo());
		pstmt1.setString(4, purchaseDetails.getPurchaseDate());
		pstmt1.setInt(5, purchaseDetails.getMobileId());
		pstmt1.executeQuery();
		conn.commit();
		
		ResultSet rs = pstmt1.executeQuery();
		rs.next();
		int purchaseId = rs.getInt(1);
		return purchaseDetails;
	}
}
